﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Doan_25.Model
{
    public class UserSession
    {
        public int UserID { set; get; }
        public string UserName { set; get; }
    }
}