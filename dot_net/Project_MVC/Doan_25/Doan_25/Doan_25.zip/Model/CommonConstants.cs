﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Doan_25.Model
{
    public class CommonConstants
    {
        public static string USER_SESSION = "USER_SESSION";
        public static string Customer_SESSION = "Customer_SESSION";
    }
}